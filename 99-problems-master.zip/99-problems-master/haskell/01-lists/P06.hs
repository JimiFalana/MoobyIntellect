isPalindrome :: Eq a => [a] -> Bool
isPalindrome list = (list == (reverse list))
