package com.shekhargulati.ninetynine_problems._03_logic_and_codes

/**
  * 3.03 (**) Truth tables for logical expressions (3).
  *
  * Skipping this problem for now.
  */
object P48 {

}
